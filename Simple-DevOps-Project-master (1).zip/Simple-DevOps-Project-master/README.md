# Simple DevOps Project

This Repository is a collection of Implementation documents. 

### Purpose:
By following this repository you can able to setup a DevOps CI/CD Pipeline using
- git
- Jenkins
- Mavine
- Ansible
- Docker &
- Kubernetes

